def lib(chip_ID):
    if chip_ID == 'BTJ7V':
        info = ('GGGNNNNNNGGGGTGGGG', 'GGGTGGGGTNNNNNNGGG', 'NNNTGGGGTGGGGTGNNN')
    elif chip_ID == 'B87B4' or chip_ID == 'CGDRJ':
        info = ('NNNNNNGGTGGGGTGGGG', 'GGGTGGNNNNNNGTGGGG', 'GGGTGGGGTGGGNNNNNN')
    elif chip_ID =='CJLFM' or chip_ID =='C2FY4':
        info = ('NNNTGGNNNGGGGTGGGG', 'GGGNNNGGTNNNGTGGGG', 'GGGTGGNNNGGGNNNGGG', 'GGGTGGGGTNNNGTGNNN')
    return info
    
def check_lib_seq(sequence, sequence_info):
    standard = 'GGGTGGGGTGGGGTGGGG'
    flag = True
    if (sequence[0:30] == "ATTAATAAATAATATTTAAAATTTATTATA" and len(sequence[30:]) == 18):
        for i in range(len(sequence_info)):
            rand_pos = [pos for pos, char in enumerate(sequence_info[i]) if char == 'N']
            fix_pos = [i for i in range(len(sequence_info[0])) if not i in rand_pos]
            flags = [True for i in range(len(fix_pos)) if sequence[30+fix_pos[i]] == standard[fix_pos[i]]]
            if len(flags) == len(fix_pos):
                flag = True
                break
            else:
                flag = False
    else:
        flag = False
    
    return flag