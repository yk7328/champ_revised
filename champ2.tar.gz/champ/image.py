import os
import re
import logging
import math
import tifffile
import numpy as np
import itertools
from PIL import Image
from collections import defaultdict
from matplotlib.image import imread
import matplotlib.pyplot as plt
import fnmatch
import scipy.misc
from champ import chip_lib_info
from skimage import io

log = logging.getLogger(__name__)

total = {}
total_mod = {}
total_list = []

def division(process_files, flipud, fliplr, rotation):
    C55_image = [os.path.join(files, 'C55_images') for files in process_files]
    image_std = io.imread('/mnt/marble/hdd/home/yakuo/CHAMP_codes/flatfield.ome.tif')
    image_drk = io.imread('/mnt/marble/hdd/home/yakuo/CHAMP_codes/070319_CGDRJ_dark_2_MMStack_Pos0.ome.tif')
    
    for C55_image_path in C55_image:
        new_directory = os.path.join(C55_image_path, 'subimages')
        regex = re.compile(r'(\w+)_(\d+)_(\d+)')
        special_chars_regex = re.compile(r'(\w+.*?)')
    
        if not os.path.exists(new_directory):
            os.makedirs(new_directory)
        
        paths = defaultdict(set)
        for directory, subdirs, filenames in os.walk(C55_image_path, topdown = True):
            subdirs[:] = list(filter(lambda x: not x in new_directory, subdirs))
            if not filenames:
                continue
            for filename in filenames:
                if not filename.endswith('.tif'):
                    continue
                position = regex.search(filename).group()
                prefix, col, row = position.split('_')
                print filename
                #with tifffile.TiffFile(os.path.join(directory, filename)) as tif:
                #    print filename
                 #   summary = tif.micromanager_metadata['summary']
                 #   raw_channel_names = tif.micromanager_metadata['summary']['ChNames']
                 #   channel_names = special_chars_regex.search(raw_channel_names[0]).group()
                
                im = io.imread(os.path.join(directory, filename))
                if flipud:
                    temp_image = np.flipud(im)
                    if fliplr:
                        temp_image = np.fliplr(temp_image)
                elif fliplr:
                    temp_image = np.fliplr(im)
                    if flipud:
                        temp_image = np.flipud(temp_image)
                else:
                    temp_image = im
                height, width = 1024, 1024 #int(summary['Height']), int(summary['Width'])
                if height % 512 != 0 or width % 512 != 0:
                    raise ValueError("CHAMP currently only supports images with sides that are multiples of 512 pixels.")
                subrows, subcolumns = range(height / 512), range(width / 512)
                
                image_post = np.true_divide(temp_image - image_drk, image_std)
               # print image_post                
                for subrows, subcolumns in itertools.product(subrows, subcolumns):
                    subimage = image_post[512*subrows:512*(subrows+1), 512*subcolumns:512*(subcolumns+1)]
                    #subimage = subimage*100
                    #subimage = np.around(subimage, 0)
                    #print subimage
                    #print subimage
                    real_rows = subrows
                    real_cols = subcolumns + int(col)*2
                    #subimage = Image.fromarray(subimage)
                    image_filename = 'Red_%03d_%03d' % (real_rows, real_cols)
                    subimage.save(os.path.join(new_directory, image_filename)+'.tif', 'TIFF')
                    #subimage.save(os.path.join(new_directory, image_filename)+'.png')
                    #plt.imsave(os.path.join(new_directory, image_filename)+'.tif', subimage, cmap = 'gray')
                    #subimage = subimage/100
                    np.save(os.path.join(new_directory, image_filename)+'.npy', subimage)
                    
                    log.debug('images saved: {}!'.format(image_filename))
                    
def mean_intensity(new_img, row, col, kernel_path):
    with open(kernel_path, 'r') as kernel:
        weight_matrix = []
        for lines in kernel:
            weight_matrix.append(lines.split())
        weight_matrix = np.array(weight_matrix)     
    interested_area = new_img[int(float(row)):int(float(row))+7, int(float(col)):int(float(col))+7]
    sum = 0
    for rows, cols in itertools.product(range(interested_area.shape[0]), range(interested_area.shape[1])):
        sum = sum + float(weight_matrix[rows, cols])*interested_area[rows, cols]
    return sum   

def image_correction(seq_path, img_path, path, img, seqfilename, regex, sub_width, min_len, max_len, sequence_info, kernel_path):
    directory_intensity = os.path.join(path, 'intensity_info')
    corrected_img = os.path.join(path, 'corrected_images')
    image_path = os.path.join(img_path, img.split('.')[0] + '.npy')
    im = np.load(image_path)    
    width, height = len(im[0]), len(im)
    number = width/sub_width
    final = []
    median_list = []
    temp_dict = {}
    phix_dict = defaultdict(list)
    new_img = im #np.zeros((width, height))
    #print new_img
    if not os.path.exists(directory_intensity):
        os.makedirs(directory_intensity)
    """       
    for row_num, col_num in itertools.product(range(16), range(16)):
        region = im[32*row_num:32*(row_num+1), 32*col_num:32*(col_num+1)]
        median = np.median(region)
        median_list.append(median)
        temp_dict[(row_num, col_num)] = median
    
    median_array = np.array(median_list)
    median_median = np.median(median_array)
    
    for key in temp_dict.keys():
        coeff = median_median / temp_dict.get(key)        
        new_img[32*key[0]:32*(key[0]+1), 32*key[1]:32*(key[1]+1)] = coeff * im[32*key[0]:32*(key[0]+1), 32*key[1]:32*(key[1]+1)]
    """ 
    prefix = regex.search(seqfilename).group()

    imgfilename = os.path.join(corrected_img, prefix)
    total[imgfilename+'.tif'] = np.median(new_img)
    #final = Image.fromarray(new_img)
    #final.save(imgfilename+'.tif', 'TIFF')
    infoname = '%s_intensity_info.txt' % prefix
    
    with open(os.path.join(directory_intensity, infoname), 'w+') as info:
        temp_dict = {}
        with open(os.path.join(seq_path, seqfilename), 'r') as subseq:
            for lines in subseq:
                seqID = lines.split()
                intensity = mean_intensity(new_img, int(float(seqID[1])), int(float(seqID[2])), kernel_path)
                #print intensity
                intensity = str(intensity)
                if chip_lib_info.check_lib_seq(seqID[3], sequence_info):
                    temp_dict[seqID[0]] = [seqID[1], seqID[2], seqID[3][:], intensity]
                else:
                    phix_dict['PhiX'].append(intensity)
            for ID, coordSeq in temp_dict.items():
                info.write('{}\t{}\n'.format(ID, '\t'.join(coordSeq)))
            log.debug('{} intensity file is saved!'.format(seqfilename))
    
def intensity_file_mod(total, process_files):
    #directory_intensity = os.path.join(p)
    for keys, values in total.items():
        total_list.append(total.get(keys))
    median_value = np.median(total_list)
    for folders in process_files:
        directory = os.path.join(folders, 'intensity_info_mod')
        previous = os.path.join(folders, 'intensity_info')
        if not os.path.exists(directory):
            os.makedirs(directory)
        for keys, values in total.items():
            if folders in keys:
                files = keys.split('/')[-1]
                files = files.split('.')[0]
                coefficient = total.get(keys) / median_value
                print os.path.join(directory, '{}_intensity_info.txt'.format(files))
                with open(os.path.join(directory, '{}_intensity_info.txt'.format(files)), 'w+') as f:
                    with open(os.path.join(previous, '{}_intensity_info.txt'.format(files)), 'r') as o:
                        for lines in o:
                            if not lines.split()[0] != 'PhiX':
                                mod_intensity = (1/coefficient) * float(lines.split()[-1])
                                ID, row, col, seq, intensity = lines.split()[0], lines.split()[1], lines.split()[2], lines.split()[3], str(str(mod_intensity))
                                f.write('{}\t{}\t{}\t{}\t{}\n'.format(ID, row, col, seq, intensity))
                            else:
                                f.write('{}\t{}\n'.format(lines.split()[0], lines.split()[1]))
    log.debug('Intensity files are modified!')


def uneven_correction(process_files, chip_ID, kernel_path, length):
    for folders in process_files:
        seq_path = os.path.join(folders, 'results/images/results_with_sequence_name')
        img_path = os.path.join(folders, 'C55_images', 'subimages')
        new_directory = os.path.join(folders, 'corrected_images')
        sub_width = 64
        rad = 3
        min_len = 0
        max_len = length    
        regex = re.compile(r'(.*?)_(\d+)_(\d+)')
        sequence_info = chip_lib_info.lib(chip_ID)
        
        if not os.path.exists(new_directory):
            os.makedirs(new_directory)    
        for seqfilename in os.listdir(seq_path):
            position = regex.search(seqfilename).group()            
            for img in os.listdir(img_path):
                if img.startswith(position):
                    image_path = os.path.join(img_path, img)
                    image_correction(seq_path, img_path, folders, img, seqfilename, regex, sub_width, min_len, max_len, sequence_info, kernel_path)
    intensity_file_mod(total, process_files)
    #print total
                    
    #for folders in process_files:
    #    intensity_path = os.path.join(folders, 'intensity_info')
    
    
    
    
    