import math
import os
import re
import numpy as np
from collections import defaultdict
import matplotlib.pyplot as plt
import itertools
import random
import numpy as np
import logging
from champ import chip_lib_info

log = logging.getLogger(__name__)

def make_histogram(seq, date, parent_directory, layer, chip_id):
    foldername = '{}_{}_{}_C55_histogram'.format(date, layer, chip_id)
    new_directory = os.path.join(parent_directory, foldername)   
    
    if not os.path.exists(new_directory):
        os.makedirs(new_directory)   
    for keys, values in seq.items():
        candidate = seq.get(keys)
        number_of_duplicates = len(candidate)
        candidate = np.array(candidate)
        image_name = '{}_{}_{}_histogram.png'.format(date, keys, chip_id)
        plt.cla()
        #bins = 20
        #hist, bins = np.histogram(candidate, bins = bins)
        #logbins = np.logspace(np.log10(bins[0]),np.log10(bins[-1]),len(bins))
        #plt.hist(candidate, bins=np.logspace(np.log10(1000),np.log10(8000), 20))
        #plt.xscale('log')
        plt.hist(candidate, bins = 'auto')
        plt.xlim(0, 6000)
        plt.title('The histogram of {}'.format(keys))
        plt.xlabel('Intensity ')
        plt.ylabel('Number of duplicates')
        plt.annotate('Number of duplicates: {}'.format(number_of_duplicates), xy=(0.6, 0.9), xycoords='axes fraction')
        plt.savefig(os.path.join(new_directory, image_name), format = "png")
        print '{} histogram is saved!'.format(keys)
        
def save_bootstrap_txt(list_final, parent_directory, chip_id, date, iteration, i, layer):
    clean_seqname = []
    clean_mean = []
    clean_sd = []
    clean_number = []
    clean_total = []
    portion = 100 - 25*i
    rankingname = '{}_{}_intensity_ranking_{}iterations_head{}_{}.txt'.format(date, chip_id, iteration, portion, layer)
    result_folder_name = '{}_statistics'.format(chip_id)
    if not os.path.exists(os.path.join(parent_directory, result_folder_name)):
        os.makedirs(os.path.join(parent_directory, result_folder_name))     
    with open(os.path.join(parent_directory, result_folder_name, rankingname), 'w+') as ranking:
        for i in list_final[0:]:
          if i[3] >= 10:
            ranking.write('{}\t{}\t{}\t{}\n'.format(i[0], i[1], i[2], i[3]))
            clean_seqname.append(i[0])
            clean_mean.append(i[1])
            clean_sd.append(i[2])
            clean_number.append(i[3])            
    clean_total.append(clean_mean)
    clean_total.append(clean_sd)
    log.debug("{} file is saved!".format(rankingname))
    return rankingname, clean_total
        
def save_bootstrap_graph(rankingname, total, parent_directory, chip_id, date, iteration, i, layer):
    clean_mean = total[0]
    clean_sd = total[1]
    portion = 100 - 25*i
    number_of_clean_data = len(clean_mean)
    x_axis = np.linspace(0, number_of_clean_data, number_of_clean_data)
    clean_mean = np.array(clean_mean)
    clean_sd = np.array(clean_sd)    
    x = np.array(x_axis)
    filename = '{}_{}_intensity_statistics_{}iterations_head{}_{}.png'.format(date, chip_id, iteration, portion, layer)
    foldername = '{}_statistics'.format(chip_id)
    plt.cla()
    plt.plot(x, clean_mean, 'k-')
    plt.fill_between(x, clean_mean - clean_sd, clean_mean + clean_sd)
    plt.ylabel('Intensity')
    plt.xlabel('Sequence Ranking')
    #plt.ylim(2000, 4000)
    plt.xlim(0, x_axis.shape[0])    
    plt.savefig(os.path.join(parent_directory, foldername, filename), format = "png")
    log.debug("{} graph is saved!".format(filename))

def bootstrap(seq_list, iteration):
    number_of_duplicates = int(len(seq_list) * 0.7)
    sd = []
    median = []
    for i in range(int(iteration)):
        bootstrap_data = []
        position = random.sample(xrange(len(seq_list)), number_of_duplicates)
        for j in range(number_of_duplicates):
           bootstrap_data.append(seq_list[position[j]])
        sd.append(np.std(bootstrap_data))
        median.append(np.median(bootstrap_data))
    temp_sd = np.mean(sd)
    temp_mean = np.mean(median)
    return temp_sd, temp_mean

def anal(process_files, parent_directory, chip_id, date, iteration, layer):
    seq = defaultdict(list)
    sequence_info = chip_lib_info.lib(chip_id)
    
    for folders in process_files:
        temp_path = os.path.join(folders, "intensity_info")        
        for files in os.listdir(temp_path):
            with open(os.path.join(temp_path, files), 'r') as info:
                for lines in info:
                    ID, row, col, seqname, intensity = lines.split()
                    intensity = float(intensity)
                    if chip_lib_info.check_lib_seq(seqname, sequence_info):
                        if not np.isnan(intensity):
                            seq[seqname[30:]].append(float(intensity))
                        
    for i in range(4):
        list_sample = []
        list_final = []        
        for keys, values in seq.items():
            temp_list = []
            for intensities in seq.get(keys):
                temp_list.append(float(intensities))
            length = len(temp_list)
            temp_list = sorted(temp_list)
            if length >= 10:
                temp_sd, temp_mean = bootstrap(temp_list[int(length*0.25*i):], iteration)        
                list_sample.append((str(keys), temp_mean, temp_sd, len(temp_list)))    
        list_final = sorted(list_sample, key = lambda x: x[1], reverse=True)               
        rankingname, total = save_bootstrap_txt(list_final, parent_directory, chip_id, date, iteration, i, layer)
        save_bootstrap_graph(rankingname, total, parent_directory, chip_id, date, iteration, i, layer)
    return seq