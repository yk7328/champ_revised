import os
import logging
from champ import ncb, error, image, lib_seq_analysis
from champ.config import ncbInfo
#from collections import defaultdict

log = logging.getLogger(__name__)

#in contoller
 

def main(clargs):

    log.debug("Checking data analysis files.")
    PhiX_intensity_stats = []
    
    if clargs.experimental_date is None:
        error.fail("Please specify the experimental date you want to analyze!")
    if clargs.alignment_layer is None:
        error.fail("Please select a layer you want to align, or both layers!")
    process_files = ncb.determine_process_files(clargs.alignment_layer, clargs.experimental_date, clargs.chip_id, clargs.parent_directory)
    if clargs.alignment_layer == 'total':
        read_names_files = [os.path.join(clargs.read_names_directory, 'read_names_of_all_seq_{}_ceiling.txt'.format(clargs.chip_id)),
                            os.path.join(clargs.read_names_directory, 'read_names_of_all_seq_{}_floor.txt'.format(clargs.chip_id))]
    else:
        read_names_files = [os.path.join(clargs.read_names_directory, 'read_names_of_all_seq_{}_{}.txt'.format(clargs.chip_id, clargs.alignment_layer))]
    for items in read_names_files:
        if not os.path.exists(items):
            error.fail("Please link the read_names_files with sequences first!")
    
    ncb.result_seq(process_files, read_names_files)
    #ncb.check_seq_results(process_files)
    image.division(process_files, clargs.flipud, clargs.fliplr, clargs.rotation_adjustment)
    image.uneven_correction(process_files, clargs.chip_id, clargs.kernel_path, clargs.lib_seq_len)
    ncb.intensity_seq_link(process_files, PhiX_intensity_stats)
    ncb.PhiX_background_eval(process_files, PhiX_intensity_stats)
    if clargs.analysis:
        seq = lib_seq_analysis.anal(process_files, clargs.parent_directory, clargs.chip_id, clargs.experimental_date, clargs.iteration, clargs.alignment_layer)
    if clargs.histogram:
        lib_seq_analysis.make_histogram(seq, clargs.experimental_date, clargs.parent_directory, clargs.alignment_layer, clargs.chip_id)