import os
from champ.error import fail
import logging
import re
from collections import defaultdict
import math
import numpy as np

log = logging.getLogger(__name__)

#in champ/

def result_seq(process_files, read_names_files):
    allSeq_dict = {}
    results_directory = [os.path.join(files, 'results/images/') for files in process_files]
    for temp in results_directory:
        new_directory = os.path.join(temp, 'results_with_sequence_name')    
        if not os.path.exists(new_directory):
            os.makedirs(new_directory)
    for read_names in read_names_files:
        with open(read_names, 'r') as allSeq:        
            for seq in allSeq:
                seq = seq.split()
                for i in seq[1:]:
                    allSeq_dict[i] = seq[0]
    for items in results_directory:            
        for files in os.listdir(items):
            if files.endswith('_all_read_rcs.txt'):
                testSeq_dict = {}
                with open(os.path.join(items, files), 'r') as test:
                    for candSeq in test:
                        candSeq = candSeq.split()
                        if allSeq_dict.get(candSeq[0]):
                            testSeq_dict[candSeq[0]] = [candSeq[1], candSeq[2], allSeq_dict[candSeq[0]]]
                results = re.search('(.*?)_(\d+)_(\d+)', files).group()
                filename = '%s_all_seq_names.txt' % results
                with open(os.path.join(items, 'results_with_sequence_name', filename), 'w+') as out:
                    for ID, coordSeq in testSeq_dict.items():
                        out.write('{}\t{}\n'.format(ID, '\t'.join(coordSeq)))
        log.debug("Finish linking {} results with their sequence name!".format(items))        

def check_seq_results(process_files):
    for folders in process_files:
        results_directory = os.path.join(folders, 'results/images/')
        new_results_directory = os.path.join(folders, 'results/images/results_with_sequence_name/')
        stat_path = folders
        filename = 'statistics.txt'   
        regex = re.compile(r'(.*?)_(\d+)_(\d+)')
    
        for files in os.listdir(results_directory):
            if not files.endswith('.txt'):
                continue
            elif files.endswith('stats.txt'):
                continue
            else:
                index = regex.search(files).group()
                with open(os.path.join(results_directory, files), 'r') as temp:
                    ID_seq = []
                    ID_ori = []
                    final = []
                    for lines in temp:
                        ID_ori.append(lines.split()[0])
                    for subfiles in os.listdir(new_results_directory):
                        if subfiles.startswith(index):
                            with open(os.path.join(new_results_directory, subfiles), 'r') as subtemp:
                                for idname in subtemp:
                                    ID_seq.append(idname.split()[0])
                    for seqID in ID_seq:
                        if seqID in ID_ori:
                            final.append(seqID)
                        else:
                            break
            with open(os.path.join(stat_path, filename), 'a+') as stat:
                if len(final) == len(ID_seq) == len(ID_ori):
                    stat.write('{}\t{}\n'.format(index, 'Well done!'))
                else:
                    stat.write('{}\t{}\n'.format(index, 'Something went wrong!'))
        log.debug("Checked the correctness of {} results sequence name files!".format(folders))
        

def determine_process_files(layers, date, chipID, parent_dir):     
    if layers == 'total':
        dirs = [os.path.join(parent_dir, name) for name in os.listdir(parent_dir) if os.path.isdir(name) and chipID in name.split('_') and date in name.split('_') and not name.endswith('histogram')]
    else:
        dirs = [os.path.join(parent_dir, name) for name in os.listdir(parent_dir) if os.path.isdir(name) and layers in name.split('_') and chipID in name.split('_') and date in name.split('_')]
    if len(dirs) == 0:
        fail("There is no folders to analyze!")
    for items in dirs:
        candidates = [folders for folders in os.listdir(os.path.join(parent_dir, items))]
        if 'C55_images' not in candidates:
            fail("Could not find C55_images folder in {}!".format(os.path.join(parent_dir, items)))    
    return  dirs
    
def intensity_seq_link(process_files, PhiX_intensity_stats):
    for folders in process_files:    
        info_directory = os.path.join(folders, 'intensity_info')
        seq = defaultdict(list)
        list_sample = []
        list_final = []
        temp_meanvalue = []
        temp_sdvalue = []
        temp_number = []
        sequencename = list()
        count = 0
    
        for files in os.listdir(info_directory):
            if files.endswith("intensity_info.txt"):
                with open(os.path.join(info_directory, files), 'r') as info:
                    for lines in info:
                        if lines.split()[0] == 'PhiX':
                            PhiX_intensity_stats.append(lines.split()[1])
                        else:
                            ID, row, col, seqname, intensity = lines.split()
                            intensity = float(intensity)
                            if not np.isnan(intensity):
                                seq[seqname[30:]].append(float(intensity))
        
        
        for keys, values in seq.items():
            temp_list = []
            for intensities in seq.get(keys):
                temp_list.append(float(intensities))        
            temp_sd = np.std(temp_list)
            temp_mean = np.mean(temp_list)
            list_sample.append((str(keys), temp_mean, temp_sd, len(temp_list)))
        
        list_final = sorted(list_sample, key = lambda x: x[1], reverse=True)
        
        for i in list_final[0:]:
            sequencename.append(i[0])
            temp_meanvalue.append(i[1])
            temp_sdvalue.append(i[2])
            temp_number.append(i[3])
            count += 1
        
        with open(os.path.join(folders, 'intensity_ranking.txt'), 'w+') as ranking:
            for i in list_final[0:]:
              if i[3] >= 0:
                ranking.write('{}\t{}\t{}\t{}\n'.format(i[0], i[1], i[2], i[3]))

def PhiX_background_eval(process_files, PhiX_intensity_stats):
    for folders in process_files:
        with open('PhiX_background_stats.txt', 'w+') as phix:
            phix.write('{}\t{}\n'.format(np.mean(PhiX_intensity_stats), np.std(PhiX_intensity_stats)))