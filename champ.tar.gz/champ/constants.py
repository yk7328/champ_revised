MISEQ_TILE_COUNT = 19
VERSION = '0.9.0'
R = 8.3144598  # gas constant in J/(mol K)
